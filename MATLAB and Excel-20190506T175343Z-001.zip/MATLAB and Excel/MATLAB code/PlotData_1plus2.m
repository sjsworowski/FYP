%imported dat from graph with two sensors and one with just one sensor
%with a higher sample frequency.

figure()
Time1=t;
Sensor1=s;
A=mean(Sensor1);
Sensor1=Sensor1-A;
C=Time1(1,:);
Time1=Time1-C;
Time1=Time1/1000;
Time1=Time1-1.080; %change this value to align the same location sensors, one with higher freq with one with lower freq.
plot(Time1,Sensor1);

hold on
Time_1=t1;
Time_2=t2;
Sensor_1=s1;
Sensor_2=s2;
E=mean(Sensor_1);
F=mean(Sensor_2);
Sensor_1=Sensor_1-E;
Sensor_2=Sensor_2-F;
D=Time_1(1,:);
Time_1=Time_1-D;
Time_2=Time_2-D;
Time_1=Time_1/1000;
Time_2=Time_2/1000;

plot(Time_1,Sensor_1);
%hold on
%plot(Time_2,Sensor_2);
xlabel('Time (s)')
ylabel('Pressure (hPa)')
legend('Sensor with higher sample rate','Sensor with lower sample rate')
