figure()
Time1=t1;
Time2=t2;
Sensor1=s1;
Sensor2=s2;
A=mean(Sensor1);
B=mean(Sensor2);
Sensor1=Sensor1-A;
Sensor2=Sensor2-B;
C=Time1(1,:);
Time1=Time1-C;
Time2=Time2-C;
Time1=Time1/1000;
Time2=Time2/1000;
plot(Time1,Sensor1,'LineWidth',4);
hold on;
plot(Time2,Sensor2,'LineWidth',4);
xlabel('Time (s)','fontsize',20)
ylabel('Pressure (hPa)','fontsize',20)
legend('Upstream Sensor','Downstream Sensor','fontsize',20)

% Find max value in Sensor 1
maxF = max(Sensor1);  
indexOfFirstMax = find(Sensor1 == maxF, 1, 'first');  % Get first element that is the max.
% Get the x and y values at that index.
maxY = Sensor1(indexOfFirstMax);
maxX = Time1(indexOfFirstMax);

% Find max value in Sensor 2
maxG = max(Sensor2);  
indexOfFirstMax2 = find(Sensor2 == maxG, 1, 'first');  % Get first element that is the max.
% Get the x and y values at that index.
maxY2 = Sensor2(indexOfFirstMax2);
maxX2 = Time2(indexOfFirstMax2);

TimeShift=maxX-maxX2;

% Find where Amplitude first exceeds 1002:
firstIndex1 = find(Sensor1 > 1002, 1, 'first');
% Get Amplitude at that index:
amplitudeAtThresh1 = Sensor1(firstIndex1);
% Get time at that index:
timeAtThresh1 = Time1(firstIndex1);

% Find where Amplitude first exceeds 1002:
firstIndex2 = find(Sensor2 > 1002, 1, 'first');
% Get Amplitude at that index:
amplitudeAtThresh2 = Sensor1(firstIndex2);
% Get time at that index:
timeAtThresh2 = Time2(firstIndex2);


without_pressureS1=
without_timeS1=
without_pressureS2=
without_timeS2=


save WithoutVasospasm without_pressureS1 

load WithoutVasospasm
load WithVasospasm

