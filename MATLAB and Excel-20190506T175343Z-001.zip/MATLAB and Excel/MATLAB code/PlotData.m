plot(Time,Sensor1);
xlabel('Time (ms)')
ylabel('Pressure (hPa)')
legend('Sensor 1')