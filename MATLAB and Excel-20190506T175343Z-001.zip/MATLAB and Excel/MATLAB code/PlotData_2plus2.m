%imported dat from graph with two sensors and one with just one sensor
%with a higher sample frequency.

figure()
Time1=t1;
Sensor1=s1;
A=mean(Sensor1);
Sensor1=Sensor1-A;
C=Time1(1,:);
Time1=Time1-C;
Time1=Time1/1000;
Time1=Time1-1.077; %change this value to align the same location sensors, one with higher freq with one with lower freq.
plot(Time1,Sensor1);
hold on

Time2=t2;
Sensor2=s2;
A=mean(Sensor2);
Sensor2=Sensor2-A;
C=Time2(1,:);
Time2=Time2-C;
Time2=Time2/1000;
Time2=Time2-1.077; %change this value to align the same location sensors, one with higher freq with one with lower freq.
plot(Time2,Sensor2);

hold on
Time_1=t3;
Time_2=t4;
Sensor_1=s3;
Sensor_2=s4;
E=mean(Sensor_1);
F=mean(Sensor_2);
Sensor_1=Sensor_1-E;
Sensor_2=Sensor_2-F;
D=Time_1(1,:);
Time_1=Time_1-D;
Time_2=Time_2-D;
Time_1=Time_1/1000;
Time_2=Time_2/1000;

plot(Time_1,Sensor_1);
hold on
plot(Time_2,Sensor_2);
xlabel('Time (s)')
ylabel('Pressure (hPa)')
legend('First Sensor upstream with higher sample rate','Second Sensor downstream with higher sample rate','First Sensor 1', 'Second Sensor 2')
