figure()
A=mean(Sensor1);
Sensor1=Sensor1-A;
C=Time1(1,:);
plot(Time1,Sensor1);
xlabel('Time (s)')
ylabel('Pressure (hPa)')
legend('Sensor 1')

% Find max value in Sensor 1
maxF = max(Sensor1);  
indexOfFirstMax = find(Sensor1 == maxF, 1, 'first');  % Get first element that is the max.
% Get the x and y values at that index.
maxY = Sensor1(indexOfFirstMax);
maxX = Time1(indexOfFirstMax);

